<?php
    class ErrorURL{
        function display(){
            echo 'This is a view error';
        }
    }

?>